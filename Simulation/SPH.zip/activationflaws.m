function [ eact ] = activationflaws(Nflaws,npart)
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here


end

