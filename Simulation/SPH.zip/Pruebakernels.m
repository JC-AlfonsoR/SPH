 coorglobal=coorbar;
 %h=(h0*(r0/Rho(i)))^2;
 [Nearpart,Dist]=rangesearch(coorglobal,coorglobal,h);
 kern=Dist;
 kern=cellfun(@(x) x*0,kern,'un',0);
 dkernx1=kern;
 dkerny1=kern;
for j=1:numrpart  
rij=Dist{j};
hk=h;
NP=Nearpart{j};
selfp=j;


dkernx=zeros(length(rij),1);
for i=1:length(rij)
q=rij(i)/hk;
if q<=2
    dx=abs(coorglobal(NP(i),1)-coorglobal(selfp,1));
       
    fac=(7/((4*pi)*((hk)^2)));
    dval=-5*q*((1-(0.5*q))^3)/hk*dx;
else
    dkernx(i)=0;
end
dkernx(i)=fac*dval;
end
dkernx1{j}=dkernx;
 end