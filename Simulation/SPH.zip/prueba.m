

bar_width=0.0076;

 a =      0.2079  ;
       b =      -271.7 ;
       c =      0.9921 ;
       d =        0.33 ;
ybar = 0:dxi:0.0214;
xbar = a*exp(b*ybar) + c*exp(d*ybar);
xbar = xbar*bar_width/2;
count=1;
for i=1:length(xbar)
   
    coorxbuffer=linspace(0,xbar(i),10);
    for j=1:length(coorxbuffer)
        coorx(count)=coorxbuffer(j);
        coory(count)=ybar(i);
        count=count+1;
        
    end
end
plot (coorx, coory, '.b')

axis([0 0.0254 0 0.0254])
[X, Y]=meshgrid(xbar,ybar);
coorbarp = [X(:) Y(:)];
